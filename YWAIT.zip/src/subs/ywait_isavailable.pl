sub peer_isavailable {
  my $status = 1;

  #
  # Set $status to 0 to disable new logins
  #

  return($status);
}

return 1;
