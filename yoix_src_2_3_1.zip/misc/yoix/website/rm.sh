#!/bin/sh
##
## Some versions of Linux had problems removing directories on NFS mounted
## file systems and that, in turn, caused make problems. This compensates
## by trying twice when there's an error, which seemed to work properly.
## May have the makefile install this as rm when we build the web site.
##

if /bin/rm "$@" 2>/dev/null;
    then :
    else /bin/rm "$@"
fi
