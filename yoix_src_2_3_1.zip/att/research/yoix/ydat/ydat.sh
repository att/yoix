#!/bin/sh
#
# The interpreter's startup behavior can be controlled by property
# files and command line options. The name of the default property
# file is yoix.properties, and the Yoix interpreter always looks
# for them in the three directories that Java associates with the
# "yoix.home", "user.home", and "user.dir" system properties. 
#
# Command line options are always processed after default property
# files are loaded. The list of officially supported options can be
# printed on standard output using the -?, --help, or --info options.
#

