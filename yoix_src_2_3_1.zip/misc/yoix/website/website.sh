#!/bin/ksh
## Change following to 'true' to use setuid
USE_SETUID=false
##
##
##
## Script that builds an image of the web site (minus a bunch of stuff) 
## from the source package. Assumes caller has built the other support
## programs, put them somewhere, and set PATH so they are picked up.
##
## Unfortunately all the 1.1.x Java compilers that we tried sometimes
## do things to one of our Java files (Yoix.java) that 1.2.x and 1.3.x
## versions of the Java virtual machine don't like. The problem only
## happens when we add the -O option to the command line that starts
## the compiler. Decided to force use of Java 1.2, but the approach
## is not general - run this on a new system and you have to update
## the case statement.
##
## Eventually can clean things up some - remove faq.html files (can be
## done right now) and don't bother copying license pdf files once we
## get PostScript versions. Also think about putting makefiles under
## web/yoix and adding a target (say version) that handles all version
## dependent updates. Could be run (by top level makefile) before we
## build the web site.
##

set -e		# quit on any error
umask 022
BASE=`pwd`

# use mkdir with option to make parent directories, too, if needed
MKDIR='mkdir -p'

if [ $# -lt 1 ]; then
    echo "$0: missing version argument - quitting" 1>&2
    exit 1
fi

VERSION=$1
if [ x"$2" = x-e ]
then
    EXTERNAL=-e
else
    EXTERNAL=
fi

WWW=$BASE/$VERSION/wwwfiles
ETC=$BASE/$VERSION/www-etc

VERSIONWWW=$WWW/$VERSION
VERSIONETC=$ETC/$VERSION
VERSIONSUFFIX=`echo $VERSION | sed 's/\./_/g'`

##
## Needed for C program CGI exec files
##
INSROOT=/home/yoix
KORNSHELL=/bin/ksh
VERSION_ETC=www-etc/$VERSION

##
## Version dependent file names
##

VERSIONINSTALLER=Yoix${VERSIONSUFFIX}
YOIXJAR=yoix.jar
YOIXDEBUGJAR=yoix_g.jar
YOIXSOURCE=yoix_src_${VERSIONSUFFIX}.zip
YWAITSOURCE=YWAIT.zip
BYZGRAFSOURCE=byzgraf.zip

##
## Definitions that are find uses to make sure we omit certain directories.
## The goal is to omit all directories that are unreadable, begin with two
## upper case letters, or contain a file named $PRIVATEMARKER.
##

PRIVATE='\( -type d -a \( -name \[A-Z\]\[A-Z\]\* -o -name .svn \) \) -prune'
UNREADABLE='\( -type d -a ! -perm -500 \) -prune'
PRIVATEMARKER="===PRIVATE==="

##
## Stop if $VERSIONWWW or $VERSIONETC exit
##

if [ -d $VERSIONWWW ]; then
    echo "$0: $VERSIONWWW already exists - quitting" 1>&2
    exit 1
fi

if [ -d $VERSIONETC ]; then
    echo "$0: $VERSIONETC already exists - quitting" 1>&2
    exit 1
fi

##
## Build version directory - subdirectories must mirror what will be
## installed on the server.
##

echo "=== building installation directories ==="
$MKDIR $VERSIONETC
cd $VERSIONETC

$MKDIR bin
$MKDIR cgi-bin
$MKDIR download

$MKDIR $VERSIONWWW
cd $VERSIONWWW

$MKDIR applications
$MKDIR demo
$MKDIR doc
$MKDIR download
$MKDIR examples
$MKDIR imgs
$MKDIR include
$MKDIR license
$MKDIR papers
$MKDIR scripts
$MKDIR spe
$MKDIR tutorials
$MKDIR tmp

$MKDIR installer
$MKDIR installer/yoix

##
## Source package - omits all directories that are unreadable, begin with
## two upper case letters, or contain a file named $PRIVATEMARKER.
##

echo "=== building source package ==="
cd $BASE
make clobber >/dev/null
$MKDIR ${VERSIONWWW}/tmp/src
eval find LICENSE.txt README_SOURCE RELEASE_NOTES att make misc att/research/yoix/apple/STORAGE/* att/research/yoix/jnlp/STORAGE/* ${UNREADABLE} -o ${PRIVATE} -o -print | cpio -pdmu ${VERSIONWWW}/tmp/src
cd ${VERSIONWWW}/tmp/src
for i in `find ${VERSIONWWW}/tmp/src -type f -name ${PRIVATEMARKER}`; do
    if [ -f "$i" ]; then
	rm -fr `dirname $i`
    fi
done
cd ${VERSIONWWW}/tmp/src
find . -print | zip ${YOIXSOURCE} -@
mv ${YOIXSOURCE} ${VERSIONETC}/download/${YOIXSOURCE}

##
## Yoix script headers
##

echo "=== collecting yoix script headers ==="
cd $BASE
make clobber >/dev/null
cd att/research/yoix
cp yoix.sh ${VERSIONETC}/download/yoix.sh
cp yoix.bat ${VERSIONETC}/download/yoix.bat

##
## Documentation for downloading.
##

echo "=== building downloadable documentation ==="
cd $BASE
make clobber >/dev/null

cd doc/yoix/reference
$MKDIR ${VERSIONWWW}/tmp/reference
perl SCRIPTS/troff2html.pl -s . -d ${VERSIONWWW}/tmp/reference
perl SCRIPTS/docidx.pl -s . -d ${VERSIONWWW}/tmp/reference

cd ${VERSIONWWW}/tmp/reference
# want to make sure the following files appear in this order
# so that on case-insensitive file systems the less important
# files are overwritten
cat <<'EOF' > CASEDUPES
./typedict/CheckBox.html
./typedict/Checkbox.html
./typedict/CheckBoxGroup.html
./typedict/CheckboxGroup.html
./typedict/JCheckbox.html
./typedict/JCheckBox.html
./typedict/JCheckboxGroup.html
./typedict/JCheckBoxGroup.html
./typedict/JScrollbar.html
./typedict/JScrollBar.html
./typedict/ScrollBar.html
./typedict/Scrollbar.html
EOF
find . -type f -name \*.html -print | {
    fgrep -v -f CASEDUPES
    cat CASEDUPES
} | zip doc.zip -@
mv doc.zip ${VERSIONETC}/download/doc.zip
cd $BASE
rm -fr ${VERSIONWWW}/tmp/reference

##
## Documentation for the web site.
##

echo "=== building server documentation ==="
cd $BASE
make clobber >/dev/null

cd doc/yoix/reference
mkdir -p ${VERSIONWWW}/doctmp/doc
perl SCRIPTS/troff2html.pl -s . -d ${VERSIONWWW}/doctmp/doc -website
perl SCRIPTS/docidx.pl -s . -d ${VERSIONWWW}/doctmp/doc -website
cd ${VERSIONWWW}/doctmp
find . -type d -print | while read dir
do
    if [ ! -d ${VERSIONWWW}/$dir ]
    then
	mkdir ${VERSIONWWW}/$dir
    fi
done
find . -type f -print | while read file
do
    $KORNSHELL $BASE/web/yoix/scripts/genpage.sh $EXTERNAL $file < $file > ${VERSIONWWW}/$file
done
rm -fr ${VERSIONWWW}/doctmp
cd $BASE

##
## Examples - server based
##

echo "=== building server examples ==="
cd $BASE
make clobber >/dev/null

cd doc/yoix/reference
perl SCRIPTS/inxs.pl -s . -d ${VERSIONWWW}/examples -t yx
cd $BASE

##
## Examples - downloadable
##

echo "=== building downloadable examples ==="
cd $BASE
make clobber >/dev/null
cd misc/yoix/examples
find README *.yx -print | zip examples.zip -@
mv examples.zip ${VERSIONETC}/download/examples.zip

##
## Tutorials - server based
##

echo "=== building server tutorials ==="
cd $BASE
make clobber >/dev/null
cd misc/yoix/tutorials
eval find . -depth ${UNREADABLE} -o ${PRIVATE} -o -print | cpio -pdmu ${VERSIONWWW}/tutorials

##
## Collect top level files for the binary release.
##

echo "=== collecting top level binary release files ==="
cd $BASE
make clobber >/dev/null
find LICENSE.txt README RELEASE_NOTES -print | zip top.zip -@
mv top.zip ${VERSIONETC}/download/top.zip

##
## Applications and scripts - currently the same but the scripts are
## supposed to be the programs users point at and is where we may have
## to deal with version dependent issues - later!!!
##

echo "=== collecting applications ==="
cd $BASE
make clobber >/dev/null
cd misc/yoix/applications
cp *.yx ${VERSIONWWW}/applications
cp *.yx ${VERSIONWWW}/scripts
cd $BASE
cd att/research/yoix/ychart/scripts/public
cp *.yxs ${VERSIONWWW}/scripts

echo "=== collecting include files ==="
cd $BASE
cd misc/yoix/include
cp *.yx ${VERSIONWWW}/include

##
## Debugging jar file
##

echo "=== building jar file (debugging version) ==="
cd $BASE
make clobber >/dev/null
cd att/research/yoix
make JAVACFLAGS="-g -nowarn" all
cd apple
make JAVACFLAGS="-g -nowarn" clobber  all
cd ..
make JAVACFLAGS="-g -nowarn" yoix.jar
mv yoix.jar $BASE
cd $BASE
zip -0 -g yoix.jar LICENSE.txt
mv yoix.jar ${VERSIONETC}/download/${YOIXDEBUGJAR}

##
## Copy installer.yx to scripts, even though it can't install anything
## if executed by users. Still can be run (nothing happens) and users
## can look at it in case they're suspicious. Use the jar we just built
## to perform the needed substitutions
##

cd $BASE
cd misc/yoix/installer
if [ -z "$EXTERNAL" ]
then
    java -jar ${VERSIONETC}/download/${YOIXDEBUGJAR} gsubsti.yx < installer._YX > ${VERSIONWWW}/scripts/installer.yx
else
    java -jar ${VERSIONETC}/download/${YOIXDEBUGJAR} gsubsti.yx -e < installer._YX > ${VERSIONWWW}/scripts/installer.yx
fi

##
## Optimized jar file - this will take a while.
##

echo "=== building jar file (production version) ==="
cd $BASE
make clobber >/dev/null
cd att/research/yoix
make JAVACFLAGS="-g:none -nowarn" all
cd apple
make JAVACFLAGS="-g:none -nowarn" clobber all
cd ..
make JAVACFLAGS="-g:none -nowarn" yoix.jar
mv yoix.jar $BASE
cd $BASE
zip -0 -g yoix.jar LICENSE.txt
mv yoix.jar ${VERSIONETC}/download/${YOIXJAR}

##
## YWAIT package - omits all directories that are unreadable, begin with
## two upper case letters, or contain a file named $PRIVATEMARKER.
##

echo "=== building YWAIT package ==="
cd $BASE
make clobber >/dev/null
$MKDIR ${VERSIONWWW}/tmp/YWAIT
cd tools/YWAIT
eval find . ${UNREADABLE} -o ${PRIVATE} -o -print | cpio -pdmu ${VERSIONWWW}/tmp/YWAIT
cd ${VERSIONWWW}/tmp/YWAIT
for i in `find ${VERSIONWWW}/tmp/YWAIT -type f -name ${PRIVATEMARKER}`; do
    if [ -f "$i" ]; then
	rm -fr `dirname $i`
    fi
done
cd ${VERSIONWWW}/tmp/YWAIT
cp ${VERSIONETC}/download/${YOIXJAR} src/jars/yoix.jar
find . -print | zip ${YWAITSOURCE} -@
mv ${YWAITSOURCE} ${VERSIONETC}/download/${YWAITSOURCE}

##
## Java Web Start support
##

echo "=== building Java Web Start support ==="
cd $BASE
$MKDIR ${VERSIONWWW}/javaws
cd web/yoix/javaws
make clobber all
cp *.jnlp ${VERSIONWWW}/javaws
for file in *.html
do
    $KORNSHELL $BASE/web/yoix/scripts/genpage.sh $EXTERNAL $file < $file > ${VERSIONWWW}/javaws/$file
done
cp htaccess ${VERSIONWWW}/javaws/.htaccess
cp -r yoix ${VERSIONWWW}/javaws/yoix
make clobber

cd $BASE
make clobber >/dev/null
cd att/research/yoix
make JAVACTARGET=1.4 JAVACFLAGS="-g:none -nowarn" all
cd apple		# is this apple stuff really necessary???
make JAVACTARGET=1.4 JAVACFLAGS="-g:none -nowarn" clobber all
cd ..
make JAVACTARGET=1.4 JAVACFLAGS="-g:none -nowarn" yoix_javaws.jar
mv yoix_javaws.jar $BASE

#
# Restore original class files (not the ones grabbed using JAVACTARGET=1.4).
#
make JAVACFLAGS="-g:none -nowarn" clobber all
cd apple
make JAVACFLAGS="-g:none -nowarn" clobber all
cd $BASE

zip -0 -g yoix_javaws.jar LICENSE.txt
mv yoix_javaws.jar ${VERSIONWWW}/javaws/yoix/yoix_javaws.jar

##
## Byzgraf package - simpler process than YWAIT... very direct
##

echo "=== building Byzgraf package ==="
cd $BASE
cd tools
ls BYZGRAF/byzgraf.yx  BYZGRAF/byzgraf_sampler.yx  BYZGRAF/byzgraf.pdf  BYZGRAF/README BYZGRAF/LICENSE.txt | zip -@ ${VERSIONETC}/download/${BYZGRAFSOURCE}

##
##  ydat script headers.
##

echo "=== collecting ydat script headers ==="
cd $BASE
make clobber >/dev/null
cd att/research/yoix/ydat
cp ydat.sh ${VERSIONWWW}/tmp
cp ydat.bat ${VERSIONWWW}/tmp

##
## Collect ydat script files.
##

echo "=== collecting ydat script files ==="
cd $BASE
make clobber >/dev/null
$MKDIR ${VERSIONWWW}/tmp/ydat
cp att/research/yoix/ydat/scripts/public/*.yx ${VERSIONWWW}/tmp/ydat
cd ${VERSIONWWW}/tmp/ydat
chmod 644 *.yx
sed 's/\(String  *HOME = \).*/\1NULL;/' ydat.yx >ydat.yx.sed
mv ydat.yx.sed ydat.yx
zip ydat.zip *.yx
mv ydat.zip ${VERSIONWWW}/tmp

##
## Collect ydat demo data files
##

echo "=== collecting ydat demo data files ==="
cd $BASE
make clobber >/dev/null
cd att/research/yoix/ydat/data/public
find demo*.data -print | zip data.zip -@
mv data.zip ${VERSIONWWW}/tmp

##
## ychart script headers.
##

echo "=== collecting ychart script headers ==="
cd $BASE
make clobber >/dev/null
cd att/research/yoix/ychart
cp ychart.sh ${VERSIONWWW}/tmp
cp ychart.bat ${VERSIONWWW}/tmp

##
## Collect ychart script and data files
##

echo "=== collecting ychart script and data files ==="
cd $BASE
make clobber >/dev/null
$MKDIR ${VERSIONWWW}/tmp/ychart
cp att/research/yoix/ychart/scripts/public/*.yx ${VERSIONWWW}/tmp/ychart
cp att/research/yoix/ychart/data/public/*.yx ${VERSIONWWW}/tmp/ychart
cd ${VERSIONWWW}/tmp/ychart
chmod 644 *.yx
zip ychart.zip *.yx
mv ychart.zip ${VERSIONWWW}/tmp

##
## Build the installer
##

echo "=== building installer ==="
cd $BASE
make clobber >/dev/null
if [ -z "$EXTERNAL" ]
then
    java -jar ${VERSIONETC}/download/${YOIXDEBUGJAR} misc/yoix/installer/gsubsti.yx < misc/yoix/installer/installer._YX > ${VERSIONWWW}/tmp/installer.yx
else
    java -jar ${VERSIONETC}/download/${YOIXDEBUGJAR} misc/yoix/installer/gsubsti.yx -e < misc/yoix/installer/installer._YX > ${VERSIONWWW}/tmp/installer.yx
fi
cp misc/yoix/installer/YoixInstaller.java ${VERSIONWWW}/tmp/YoixInstaller.java
cp misc/yoix/installer/buildinstaller.yx ${VERSIONWWW}/tmp
cp misc/yoix/applications/exec.yx ${VERSIONWWW}/tmp
cp ${VERSIONETC}/download/* ${VERSIONWWW}/tmp
cd ${VERSIONWWW}/tmp

zip yoix.zip installer.yx yoix.jar exec.yx yoix.sh yoix.bat ydat.sh ydat.bat ychart.sh ychart.bat ydat.zip data.zip ychart.zip examples.zip top.zip

echo "Main-Class: ${VERSIONINSTALLER}" >${VERSIONINSTALLER}.mf
sed "s/YoixInstaller/${VERSIONINSTALLER}/g" YoixInstaller.java >${VERSIONINSTALLER}.java
java -jar yoix.jar buildinstaller.yx ${VERSIONINSTALLER}.java yoix.zip >xxx.java
mv xxx.java ${VERSIONINSTALLER}.java
javac -source 1.2 -target 1.2 ${VERSIONINSTALLER}.java
jar cvfm ${VERSIONINSTALLER}.jar ${VERSIONINSTALLER}.mf ${VERSIONINSTALLER}.class
rm -f ${VERSIONINSTALLER}.java ${VERSIONINSTALLER}.mf
####mv ${VERSIONINSTALLER}.class ${VERSIONETC}/download/${VERSIONINSTALLER}.class
mv ${VERSIONINSTALLER}.jar ${VERSIONETC}/download/${VERSIONINSTALLER}.jar

##
## Collect installer support files
##

echo "=== collecting installer support files ==="
cd $BASE
cp misc/yoix/installer/yoix/*.image ${VERSIONWWW}/installer/yoix
cp misc/yoix/installer/yoix/*.txt ${VERSIONWWW}/installer/yoix

##
## Collecting images
##

echo "=== collecting images ==="
cd $BASE
cd web/yoix/images
cp *.png *.jpg *.gif ${VERSIONWWW}/imgs

##
## Collecting papers
##

echo "=== collecting papers ==="
cd $BASE
cp web/yoix/documents/yoix_intro.pdf ${VERSIONWWW}/papers/yoix_intro.pdf
cp web/yoix/documents/lncs23760090.pdf ${VERSIONWWW}/papers/lncs23760090.pdf
cp web/yoix/documents/SPE_PrePrint.pdf ${VERSIONWWW}/papers/SPE_PrePrint.pdf
cp web/yoix/documents/yoix_tutorial.pdf ${VERSIONWWW}/papers/yoix_tutorial.pdf
cd doc/yoix/introduction
make paper.ps
ps2pdf paper.ps ${VERSIONWWW}/papers/yoix_paper.pdf

##
## Collecting demos
##

echo "=== collecting demos ==="
cd $BASE
cp web/yoix/media/*.mov ${VERSIONWWW}/demo

##
## Collecting SP&E files
##

echo "=== collecting SP&E files ==="
cd $BASE
for file in calculator.yx factorial.py factorial.yx \
            FactorModule.java index.html Testing.zip
do
    cp web/yoix/spe/$file ${VERSIONWWW}/spe/$file
done

##
## Collecting server html files
##

echo "=== collecting server html files ==="
cd $BASE
cd web/yoix/html
cp license/*.pdf license/*.txt $VERSIONWWW/license/
chmod a+x $BASE/web/yoix/scripts/genpage.sh
for file in `find . -name SCCS\* -prune -o -name \*.html -print`; do
    if [ -r $file ]; then
	echo "$file"
	sed -e "s/<VERSION_NUMBER>/$VERSIONSUFFIX/g" < $file | $BASE/web/yoix/scripts/genpage.sh $EXTERNAL $file > $VERSIONWWW/$file
    fi
done

##
## Collect tutorial support files
##

echo "=== collecting tutorial support files ==="
cd $BASE
$MKDIR ${VERSIONWWW}/yoix_tutorial_files
cp web/yoix/html/yoix_tutorial_files/* ${VERSIONWWW}/yoix_tutorial_files
chmod 644 ${VERSIONWWW}/yoix_tutorial_files/*

##
## Build and collect faq html files - probably should happen after
## collecting server html files, so we overwrite old files that may
## have been installed.
##

echo "=== collecting faq html files ==="
cd $BASE
cd web/yoix/faq
perl ../scripts/faqs.pl -c License -s -t -v "$VERSIONSUFFIX" *.faq | $BASE/web/yoix/scripts/genpage.sh $EXTERNAL ./license/faq.html > $VERSIONWWW/license/faq.html
perl ../scripts/faqs.pl -C License -v "$VERSIONSUFFIX" *.faq | $BASE/web/yoix/scripts/genpage.sh $EXTERNAL ./faq.html > $VERSIONWWW/faq.html

##
## Install cgi scripts into internal and external cgi-bin areas, which
## are not under the current release 
## have been installed.
##

echo "=== installing cgi-bin and related bin files ==="
if $USE_SETUID; then
    cd $BASE
    cd web/yoix/cgi
    for file in *._C; do
	if [ -r $file ]; then
	    echo "$file"
	    sed -e "s!<_KORNSHELL_>!$KORNSHELL!" \
		-e "s!<_INSROOT_>!$INSROOT!" \
		-e "s!<_VERSION_ETC_>!$VERSION_ETC!" \
		< $file > $VERSIONETC/bin/${file%._C}.c
	    echo "================================================"
	    echo "In $VERSIONETC/bin:"
	    echo "Execute: gcc -o $INSROOT/cgi-bin/${file%._C} ${file%._C}.c"
	    echo "Then: chmod 04755 $INSROOT/cgi-bin/${file%._C}"
	    echo "================================================"
	fi
    done
    cd $BASE
    echo "genpage.ksh"
    cp web/yoix/scripts/genpage.sh $VERSIONETC/bin/genpage.ksh
    chmod 755 $VERSIONETC/bin/genpage.ksh
    cd web/yoix/bin
    for file in *.ksh; do
	if [ -r $file ]; then
	    echo "$file"
	    cp $file $VERSIONETC/bin/$file
	fi
    done
else
    cd $BASE
    echo "genpage.ksh"
    cp web/yoix/scripts/genpage.sh $VERSIONETC/bin/genpage.ksh
    chmod 755 $VERSIONETC/bin/genpage.ksh
    cd web/yoix/bin
    for file in *.ksh; do
	filebase=${file%.ksh}
	if [ -r $file ]; then
	    if [ -r ../cgi/$filebase._C ]; then
		echo "$filebase"
		cp $file $VERSIONETC/cgi-bin/$filebase
		chmod 750 $VERSIONETC/cgi-bin/$filebase
	    else
		echo "$file"
		cp $file $VERSIONETC/bin/$file
	    fi
	fi
    done
    echo "================================================"
    echo "REMEMBER:"
    echo "Move files in $VERSIONETC/cgi-bin to proper server directory"
    echo "================================================"
fi

##
## Remove unnecessary directories that we may have created or collected.
##

set +e		# ignore chmod errors during cleanup

echo "=== directory cleanup ==="
cd $BASE
rm -fr ${VERSIONWWW}/tmp
cd ${VERSIONWWW}
find ${VERSIONWWW} -type d -name SCCS\* -print | xargs chmod u+rwx 2>/dev/null
find ${VERSIONWWW} -type d -name SCCS\* -print | xargs rm -fr
find ${VERSIONWWW} -type d -name BACKUP\* -print | xargs chmod u+rwx 2>/dev/null
find ${VERSIONWWW} -type d -name BACKUP\* -print | xargs rm -fr
find ${VERSIONWWW} -type d -name RCS\* -print | xargs chmod u+rwx 2>/dev/null
find ${VERSIONWWW} -type d -name RCS\* -print | xargs rm -fr

##
## Final permissions
##
 
echo "=== setting permissions ==="
cd $BASE
make clobber >/dev/null

cd ${VERSIONETC}
find ${VERSIONETC} -print | xargs chmod +r,u+w,go-w
find ${VERSIONETC}/cgi-bin -print | xargs chmod +x

cd ${VERSIONWWW}
find ${VERSIONWWW} -print | xargs chmod +r,u+w,go-w

